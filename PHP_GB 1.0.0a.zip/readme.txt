// DARKSYNX @ 2015 

copy your script in folder "phar\"
the first file execute is "int.phx" just as "index.php" 
if you want y can change this in Pharit.phx in line 32

file is phar dont use Var _FILE_ use realpath('.') 
well if you want CLS script execute Packed_CLS.bat
or WIn mode Packed_WIN.bat

"mydev.ico" is your icon for exe 
when compaction is complete go in the bin folder recover


ps: 
personally I use the file extension phx 
You are not forced to use it
see ya ++ (^_^)

