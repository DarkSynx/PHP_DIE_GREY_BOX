// DARKSYNX @ 2015 2.0.0.a

1 . copy your script ".php" or ".phx" in folder "phar\" 
2 . add your Extension php in Folder PHP\ and in PHP\php.ini ; 
3 . add your file or your .ico in php\ folder , for exemple if you want use "wb_set_image($winmain, "mydev.ico");"
4 . does not create a sub folder in "php\" ; the program is incompatible with subfolders, and they will not add .

* remember MSVCR110.dll is MSVC++ 2012 https://www.microsoft.com/en-US/download/details.aspx?id=30679
* remember the first file execute is "int.phx" just as "index.php" 

file in phar option dont use Var _FILE_ use realpath('.') 
_FILE_ starts in Phar:// not in current folder

"mydev.ico" next PHP_GB.exe is your icon EXE . 
I patching Php.exe or Php-win.exe original with reshacker to change the icon of the executable

when compaction is complete go in the "bin\" folder recover your APP
you can use "debug.bat" for test APP

ps: 
personally I use the file extension phx 
You are not forced to use it
see ya ++ (^_^)

